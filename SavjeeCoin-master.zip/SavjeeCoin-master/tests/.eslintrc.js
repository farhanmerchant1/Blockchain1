module.exports = {
    "extends": "../.eslintrc.js",
    "globals": {
        "describe": "readonly",
        "it": "readonly",
        "beforeEach": "readonly"
    }
}
