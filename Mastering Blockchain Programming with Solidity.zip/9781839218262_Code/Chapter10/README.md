We are using MultiSigWallet repository. To update submodule execute the below command: 
```bash
git submodule update --init --force --recursive --remote
```
