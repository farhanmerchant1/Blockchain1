To install the dependencies of the project, run the following command:
```bash
npm install
```

##### Compile
```bash
truffle compile
```