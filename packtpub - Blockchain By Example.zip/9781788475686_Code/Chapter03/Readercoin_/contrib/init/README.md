Sample configuration files for:
```
SystemD: readercoind.service
Upstart: readercoind.conf
OpenRC:  readercoind.openrc
         readercoind.openrcconf
CentOS:  readercoind.init
OS X:    org.readercoin.readercoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
