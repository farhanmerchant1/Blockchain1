RPC Tools
---------------------

### [RPCUser](/share/rpcuser) ###

Create an RPC user login credential.

Usage:

    ./rpcuser.py <username>
