# Bitcoin_payment
Code for the second section of the second Chapter.

## Setup: 
Detailed instructions are available on the book. To run the project please follow the instruction below :

<ul>
<li>1-Run first the payment server</li>
<li>2-Import the project into eclipse (IDE)</li>
<li>3-Edit the url string using your own bip72 payment url</li>
<li>4-Get few bitcoins from the faucet</li>
</ul>



